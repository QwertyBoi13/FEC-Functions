// sum.c

#include "sum.h"

int sum_pass_by_value(int num1, int num2) {
  return(num1 + num2);
}

void sum_pass_by_reference(int num1, int num2, int *result)  {
  *result = num1 + num2;
}