#include "sum.h"
#include <stdio.h>
#include <stdlib.h>
void usage(char *cmd) {
  puts("Usage:");
  printf("%s NUM1 NUM2\n", cmd);
  printf("Be sure to use only 2 numbers\n");
}

int main(int argc, char *argv[]) {
  printf("Functions\n");
  printf("Code by Levi Leichtfuss\n");

  if (argc != 4) {
    usage(argv[0]);
    //printf("%s, %s, %s\n", argv[0], argv[1], argv[2]);
    return 0;
  }

  int sum = 0;
  int num1 = atoi(argv[2]);
  int num2 = atoi(argv[3]);

  sum = sum_pass_by_value(num1, num2);
  printf("sum_pass_by_value: %d\n", sum);
  int result; 
  sum_pass_by_reference(num1, num2, &result);
  printf("sum_pass_by_reference: %d\n", result);

  return 0;
}