// sum.h

#ifndef _SUM_H_
#define _SUM_H_

int sum_pass_by_value(int num1, int num2);

void sum_pass_by_reference(int num1, int num2, int *result);

#endif
